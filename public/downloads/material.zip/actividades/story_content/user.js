function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6YR27X1Kt91":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

